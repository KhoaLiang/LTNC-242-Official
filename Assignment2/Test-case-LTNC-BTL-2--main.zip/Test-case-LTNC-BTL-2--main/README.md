# Test-case-LTNC-BTL-2-
1. **Download** the `main.java` file to your computer.  
2. **Overwrite** the existing `main.java` file in `src\main\java\com\myproject\main.java` with the downloaded file.  
3. **Compile** the project as you normally would.  
